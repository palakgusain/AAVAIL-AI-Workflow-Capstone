import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
import joblib
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from src.config import PROCESSED, ARTIFACTS, FEATURES, TARGET, MODEL, METRICS
from src.ingestion import ingest_data
from src.logging_config import configure_logging

logger = configure_logging("aavail.train")

def preprocessor():
    numeric = Pipeline([("imputer", SimpleImputer(strategy="median", add_indicator=True)),
                        ("scale", StandardScaler())])
    categorical = Pipeline([("imputer", SimpleImputer(strategy="constant", fill_value="missing")),
                            ("onehot", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("numeric", numeric, ["age", "num_streams"]),
                              ("categorical", categorical, ["country_name", "subscriber_type"])])

def run_training():
    if not PROCESSED.exists():
        ingest_data()
    df = pd.read_csv(PROCESSED).dropna(subset=[TARGET])
    X, y = df[FEATURES], df[TARGET].astype(bool).astype(int)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=.25, random_state=42, stratify=y)
    candidates = {
        "Dummy baseline": DummyClassifier(strategy="most_frequent"),
        "Logistic Regression": LogisticRegression(max_iter=1000),
        "Random Forest": RandomForestClassifier(n_estimators=250, max_depth=6,
            min_samples_leaf=4, class_weight="balanced", random_state=42)
    }
    models, results = {}, {}
    for name, estimator in candidates.items():
        pipe = Pipeline([("preprocessor", preprocessor()), ("model", estimator)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        prob = pipe.predict_proba(X_test)[:, 1]
        row = {
            "accuracy": float(accuracy_score(y_test, pred)),
            "precision": float(precision_score(y_test, pred, zero_division=0)),
            "recall": float(recall_score(y_test, pred, zero_division=0)),
            "f1": float(f1_score(y_test, pred, zero_division=0))
        }
        try:
            row["roc_auc"] = float(roc_auc_score(y_test, prob))
        except ValueError:
            row["roc_auc"] = None
        models[name], results[name] = pipe, row
        logger.info("%s: %s", name, row)
    best = max((n for n in results if n != "Dummy baseline"), key=lambda n: results[n]["f1"])
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    joblib.dump(models[best], MODEL)
    report = {"selected_model": best, "test_rows": int(len(y_test)),
              "target": TARGET, "positive_class": "currently_subscribed",
              "model_results": results,
              "warning": "Small snapshot dataset; metrics are exploratory, not causal evidence."}
    METRICS.write_text(json.dumps(report, indent=2))
    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(list(results), [results[n]["f1"] for n in results])
    ax.set_title("Model Comparison on Held-Out Test Data")
    ax.set_ylabel("F1 score")
    ax.set_ylim(0, 1)
    ax.grid(axis="y", alpha=.25)
    for bar, name in zip(bars, results):
        ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+.02,
                f"{results[name]['f1']:.3f}", ha="center")
    plt.xticks(rotation=10, ha="right")
    fig.tight_layout()
    fig.savefig(ARTIFACTS / "model_comparison.png", dpi=160)
    plt.close(fig)
    return report

if __name__ == "__main__":
    print(json.dumps(run_training(), indent=2))
