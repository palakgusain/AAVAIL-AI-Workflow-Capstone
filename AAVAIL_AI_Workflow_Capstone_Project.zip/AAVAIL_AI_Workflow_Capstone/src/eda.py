import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from src.config import RAW, PROCESSED, ARTIFACTS
from src.ingestion import ingest_data
from src.logging_config import configure_logging

logger = configure_logging("aavail.eda")

def run_eda():
    df = pd.read_csv(PROCESSED) if PROCESSED.exists() else ingest_data()[0]
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    missing = df.isna().sum()
    missing = missing[missing > 0]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    if len(missing):
        bars = ax.bar(missing.index, missing.values / len(df) * 100)
        ax.set_ylabel("Rows missing (%)")
        for bar, count in zip(bars, missing.values):
            ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+.15,
                    f"{count} ({count/len(df)*100:.1f}%)", ha="center")
    else:
        ax.text(.5, .5, "No missing values", ha="center")
    ax.set_title("Missing Values by Feature")
    ax.grid(axis="y", alpha=.25)
    fig.tight_layout()
    fig.savefig(ARTIFACTS / "missing_values.png", dpi=160)
    plt.close(fig)

    d = df.copy()
    d["churned"] = ~d["is_subscriber"].astype(bool)
    rates = d.groupby("country_name")["churned"].mean().mul(100).sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(8, 4.5))
    bars = ax.bar(rates.index, rates.values)
    ax.set_title("Observed Churn Rate by Country")
    ax.set_ylabel("Churn rate (%)")
    ax.set_ylim(0, max(70, rates.max()*1.2))
    ax.grid(axis="y", alpha=.25)
    for bar, value in zip(bars, rates.values):
        ax.text(bar.get_x()+bar.get_width()/2, value+1, f"{value:.1f}%", ha="center")
    fig.tight_layout()
    fig.savefig(ARTIFACTS / "churn_by_country.png", dpi=160)
    plt.close(fig)

    plan = d.dropna(subset=["subscriber_type"]).groupby(
        ["subscriber_type", "country_name"]
    )["churned"].mean().mul(100).unstack()
    ax = plan.plot(kind="bar", figsize=(9, 5))
    ax.set_title("Observed Churn by Subscription Type and Country")
    ax.set_ylabel("Churn rate (%)")
    ax.set_xlabel("Subscription type")
    ax.grid(axis="y", alpha=.25)
    plt.xticks(rotation=0)
    plt.tight_layout()
    plt.savefig(ARTIFACTS / "churn_by_plan.png", dpi=160)
    plt.close()
    summary = {
        "rows": int(len(df)),
        "missing_counts": {k: int(v) for k, v in df.isna().sum().items()},
        "churn_rate_by_country": {str(k): round(float(v), 4) for k, v in rates.items()},
        "interpretation": "Descriptive association does not establish causation."
    }
    (ARTIFACTS / "eda_summary.json").write_text(json.dumps(summary, indent=2))
    logger.info("EDA completed for %d rows", len(df))
    return summary

if __name__ == "__main__":
    print(json.dumps(run_eda(), indent=2))
