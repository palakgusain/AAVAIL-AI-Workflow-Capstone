import json
import pandas as pd
from src.config import RAW, PROCESSED, REQUIRED, ARTIFACTS
from src.logging_config import configure_logging

logger = configure_logging("aavail.ingestion")

def ingest_data(input_path=RAW, output_path=PROCESSED):
    input_path, output_path = __import__("pathlib").Path(input_path), __import__("pathlib").Path(output_path)
    if not input_path.exists():
        raise FileNotFoundError(f"Dataset not found: {input_path}")
    df = pd.read_csv(input_path)
    missing_cols = sorted(set(REQUIRED) - set(df.columns))
    if missing_cols:
        raise ValueError(f"Missing required columns: {missing_cols}")
    df["country_name"] = df["country_name"].astype("string").str.strip().str.lower()
    df["is_subscriber"] = df["is_subscriber"].astype("boolean")
    for col in ["age", "num_streams"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")
    report = {
        "rows": int(len(df)),
        "columns": list(df.columns),
        "missing_values": {k: int(v) for k, v in df.isna().sum().items()},
        "country_counts": {str(k): int(v) for k, v in df["country_name"].value_counts(dropna=False).items()},
        "dropped_columns": [],
        "imputation": "Predictor imputation occurs inside the training pipeline; no target-based imputation."
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    ARTIFACTS.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    (ARTIFACTS / "ingestion_report.json").write_text(json.dumps(report, indent=2))
    logger.info("Ingested %d rows. Missing values: %s", len(df), report["missing_values"])
    return df, report

if __name__ == "__main__":
    ingest_data()
