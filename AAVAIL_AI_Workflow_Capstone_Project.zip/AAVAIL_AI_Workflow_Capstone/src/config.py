from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
ARTIFACTS = ROOT / "artifacts"
LOGS = ROOT / "logs"
RAW = DATA / "aavail-data-visualization.csv"
PROCESSED = DATA / "processed_customers.csv"
MODEL = ARTIFACTS / "churn_model.joblib"
METRICS = ARTIFACTS / "metrics.json"
FEATURES = ["country_name", "age", "subscriber_type", "num_streams"]
TARGET = "is_subscriber"
COUNTRY_ALIASES = {
    "singapore": "singapore", "sg": "singapore",
    "united states": "united_states", "united_states": "united_states",
    "us": "united_states", "usa": "united_states", "u.s.": "united_states"
}
REQUIRED = ["customer_id", "country_name", "age", "customer_name",
            "is_subscriber", "subscriber_type", "num_streams"]
