import pandas as pd
import joblib
from src.config import MODEL, RAW, PROCESSED, COUNTRY_ALIASES

def load_model():
    if not MODEL.exists():
        raise FileNotFoundError("Model missing. Run `python -m src.ingestion` and `python -m src.train`.")
    return joblib.load(MODEL)

def load_reference_data():
    path = PROCESSED if PROCESSED.exists() else RAW
    if not path.exists():
        raise FileNotFoundError(f"Dataset not found: {path}")
    return pd.read_csv(path)

def normalize_country(country):
    key = country.strip().lower()
    if key not in COUNTRY_ALIASES:
        raise ValueError("Unsupported country. Use 'singapore' or 'united_states'.")
    return COUNTRY_ALIASES[key]
