from datetime import datetime, timezone
from threading import Lock
from time import perf_counter
from typing import Optional, Literal
import pandas as pd
from fastapi import FastAPI, HTTPException, Query, Request
from pydantic import BaseModel, Field
from src.config import FEATURES, MODEL
from src.logging_config import configure_logging
from src.model_utils import load_model, load_reference_data, normalize_country

logger = configure_logging("aavail.api")
app = FastAPI(title="AAVAIL Subscriber Status API", version="1.0.0",
              description="Estimates current subscription probability and churn risk.")
lock = Lock()
stats = {"requests": 0, "errors": 0, "total_latency_ms": 0.0, "last_request_utc": None}

class CustomerFeatures(BaseModel):
    country_name: Literal["singapore", "united_states", "united states", "us", "usa"]
    age: float = Field(ge=0, le=120)
    subscriber_type: Optional[str] = None
    num_streams: Optional[float] = Field(default=None, ge=0)

@app.middleware("http")
async def monitor_requests(request: Request, call_next):
    start = perf_counter()
    error = False
    try:
        response = await call_next(request)
        error = response.status_code >= 500
        return response
    except Exception:
        error = True
        raise
    finally:
        latency = (perf_counter() - start) * 1000
        with lock:
            stats["requests"] += 1
            stats["errors"] += int(error)
            stats["total_latency_ms"] += latency
            stats["last_request_utc"] = datetime.now(timezone.utc).isoformat()
        logger.info("method=%s path=%s latency_ms=%.2f error=%s",
                    request.method, request.url.path, latency, error)

@app.get("/health")
def health():
    return {"status": "ok", "model_available": MODEL.exists()}

@app.get("/metrics")
def metrics():
    with lock:
        result = dict(stats)
    result["average_latency_ms"] = round(
        result["total_latency_ms"] / result["requests"], 3
    ) if result["requests"] else 0.0
    result.pop("total_latency_ms", None)
    return result

@app.post("/predict")
def predict_customer(customer: CustomerFeatures):
    try:
        country = normalize_country(customer.country_name)
        record = customer.model_dump()
        record["country_name"] = country
        X = pd.DataFrame([{k: record.get(k) for k in FEATURES}])
        model = load_model()
        probability = float(model.predict_proba(X)[0, 1])
        prediction = bool(model.predict(X)[0])
        return {"country": country, "predicted_is_subscriber": prediction,
                "is_subscriber_probability": round(probability, 4),
                "estimated_churn_probability": round(1-probability, 4)}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/predict")
def predict_market(country: Optional[str] = Query(default=None)):
    try:
        df = load_reference_data()
        market = "all_countries_combined"
        if country:
            normalized = normalize_country(country)
            df = df[df["country_name"].astype(str).str.lower() == normalized]
            if df.empty:
                raise HTTPException(status_code=404, detail=f"No records found for {normalized}")
            market = normalized
        model = load_model()
        X = df[FEATURES]
        prob = model.predict_proba(X)[:, 1]
        pred = model.predict(X)
        return {"market": market, "customer_count": int(len(df)),
                "predicted_subscriber_rate": round(float(pred.mean()), 4),
                "predicted_churn_rate": round(float(1-pred.mean()), 4),
                "mean_subscriber_probability": round(float(prob.mean()), 4),
                "mean_churn_probability": round(float((1-prob).mean()), 4),
                "note": "Model estimates on supplied reference records; not future observed churn."}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
