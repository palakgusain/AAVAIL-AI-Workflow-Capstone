# AAVAIL AI Workflow Capstone

An end-to-end example workflow built from the supplied AAVAIL customer CSV. It includes automated data ingestion, exploratory visualizations, train/test evaluation of multiple classifiers, a FastAPI prediction service, request logging, lightweight performance metrics, unit tests, Docker, and GitHub Actions.

## Business question
Can customer attributes and market information estimate whether a customer is currently subscribed, and how do model predictions differ between the United States and Singapore?

`is_subscriber=True` means currently subscribed. `False` is treated as not currently subscribed/churned for this exploratory exercise. This snapshot dataset does not tell us when or why a customer churned; predictions are not guaranteed outcomes.

## Structure
- `data/aavail-data-visualization.csv` — supplied dataset
- `src/ingestion.py` — validates schema, normalizes country labels, writes a report and processed CSV
- `src/eda.py` — creates missing-data, country-churn, and plan-level charts
- `src/train.py` — compares a dummy baseline, logistic regression, and random forest
- `src/api.py` — customer prediction endpoint, country-specific and combined market predictions, health and monitoring endpoints
- `tests/` — model, API, and logging tests
- `Dockerfile`, `docker-compose.yml` — container deployment
- `.github/workflows/tests.yml` — CI test workflow

## Run locally
Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m src.ingestion
python -m src.eda
python -m src.train
python run_tests.py
uvicorn src.api:app --host 0.0.0.0 --port 8000
```

API docs: `http://127.0.0.1:8000/docs`

## API examples
Health: `GET /health`

Country-specific prediction summary:
`GET /predict?country=singapore`

All countries combined:
`GET /predict`

Single-customer estimate:
```bash
curl -X POST http://127.0.0.1:8000/predict -H "Content-Type: application/json" -d "{\"country_name\":\"singapore\",\"age\":29,\"subscriber_type\":\"aavail_basic\",\"num_streams\":12}"
```

`/metrics` returns request count, error count, average latency, and last request timestamp. These are basic application metrics, not a substitute for production monitoring.

## Data quality and imputation
The supplied file contains 1,000 records and seven columns. Missing values occur in `subscriber_type` (72; 7.2%) and `num_streams` (46; 4.6%). The ingestion step preserves these missing predictor values; imputation is performed inside the scikit-learn training pipeline, fit only on the training split to avoid leakage.

## Model evaluation
The training workflow uses a stratified holdout set and compares:
- `DummyClassifier` majority-class baseline
- Logistic Regression
- Random Forest

Metrics include accuracy, precision, recall, F1, and ROC-AUC where calculable. The model with the highest held-out F1 among the non-baseline models is saved as `artifacts/churn_model.joblib`; metrics and a comparison plot are also saved under `artifacts/`.

## Docker
```bash
docker compose up --build
```

## Limitations and recommended next steps
This is a capstone/demo workflow, not a production-approved churn model. Validate the target and feature definitions with AAVAIL. Add longitudinal data, cancellation dates, content/language engagement, pricing, tenure, and acquisition channel. Evaluate on a time-based split once dates are available. Investigate Singapore churn with customer interviews and controlled retention experiments. Production deployment should add authentication, request limits, model/version tracking, centralized monitoring, drift detection, and scheduled performance evaluation.
