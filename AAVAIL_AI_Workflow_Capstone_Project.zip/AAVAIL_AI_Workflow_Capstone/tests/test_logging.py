from src.logging_config import configure_logging

def test_logging_configured():
    logger = configure_logging("aavail.test")
    assert logger.name == "aavail.test"
    assert logger.handlers
