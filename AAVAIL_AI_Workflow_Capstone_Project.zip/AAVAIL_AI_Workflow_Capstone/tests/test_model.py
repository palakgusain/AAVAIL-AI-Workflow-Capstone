import pandas as pd
from src.config import FEATURES, MODEL
from src.model_utils import load_model

def test_feature_contract():
    assert FEATURES == ["country_name", "age", "subscriber_type", "num_streams"]

def test_model_predicts_valid_probability():
    if not MODEL.exists():
        return
    model = load_model()
    sample = pd.DataFrame([{"country_name":"singapore", "age":28,
                            "subscriber_type":"aavail_basic", "num_streams":12}])[FEATURES]
    p = float(model.predict_proba(sample)[0, 1])
    assert 0 <= p <= 1
