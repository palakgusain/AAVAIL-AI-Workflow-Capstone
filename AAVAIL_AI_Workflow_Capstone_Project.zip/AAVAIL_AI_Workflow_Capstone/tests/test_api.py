from fastapi.testclient import TestClient
from src.api import app

client = TestClient(app)

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_metrics():
    response = client.get("/metrics")
    assert response.status_code == 200
    assert "requests" in response.json()

def test_singapore_prediction_summary():
    assert client.get("/predict?country=singapore").status_code in (200, 503)

def test_combined_prediction_summary():
    assert client.get("/predict").status_code in (200, 503)

def test_invalid_country():
    assert client.get("/predict?country=Atlantis").status_code == 400
